// Routine Finder (no frameworks)
// Data file: routine_clean.csv

const els = {
  q: document.getElementById("q"),
  day: document.getElementById("day"),
  slot: document.getElementById("slot"),
  course: document.getElementById("course"),
  teacher: document.getElementById("teacher"),
  semsec: document.getElementById("semsec"),
  room: document.getElementById("room"),
  tbody: document.getElementById("tbody"),
  count: document.getElementById("count"),
  reset: document.getElementById("reset"),
};

function parseCSV(text) {
  // Robust enough for typical Excel exports (handles quotes + commas inside quotes)
  const rows = [];
  let row = [];
  let cur = "";
  let inQuotes = false;

  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    const next = text[i + 1];

    if (ch === '"') {
      if (inQuotes && next === '"') { // escaped quote
        cur += '"';
        i++;
      } else {
        inQuotes = !inQuotes;
      }
      continue;
    }

    if (!inQuotes && (ch === "," || ch === "\n" || ch === "\r")) {
      if (ch === "\r" && next === "\n") continue; // handle CRLF
      row.push(cur);
      cur = "";

      if (ch === "\n" || ch === "\r") {
        // finalize row if it's not empty
        const isEmpty = row.every(v => (v ?? "").trim() === "");
        if (!isEmpty) rows.push(row);
        row = [];
      }
      continue;
    }

    cur += ch;
  }

  // last cell
  if (cur.length || row.length) row.push(cur);
  const isEmpty = row.every(v => (v ?? "").trim() === "");
  if (!isEmpty) rows.push(row);

  if (!rows.length) return [];

  const headers = rows[0].map(h => (h ?? "").trim());
  return rows.slice(1).map(r => {
    const obj = {};
    headers.forEach((h, idx) => obj[h] = (r[idx] ?? "").trim());
    return obj;
  });
}

function uniq(arr) {
  return Array.from(new Set(arr.filter(Boolean)));
}

function slotOrder(slot) {
  // "Slot 3 (12:15 PM)" -> 3 ; fallback large
  const m = /slot\s*(\d+)/i.exec(slot || "");
  return m ? Number(m[1]) : 9999;
}

function fillSelect(selectEl, values, labelAll) {
  selectEl.innerHTML = "";
  const optAll = document.createElement("option");
  optAll.value = "";
  optAll.textContent = labelAll;
  selectEl.appendChild(optAll);

  values.forEach(v => {
    const opt = document.createElement("option");
    opt.value = v;
    opt.textContent = v;
    selectEl.appendChild(opt);
  });
}

function currentFilters() {
  return {
    q: (els.q.value || "").toLowerCase().trim(),
    day: els.day.value,
    slot: els.slot.value,
    course: els.course.value,
    teacher: els.teacher.value,
    semsec: els.semsec.value,
    room: els.room.value,
  };
}

function applyFilters(rows) {
  const f = currentFilters();

  return rows.filter(r => {
    const matchQ =
      !f.q ||
      [r.Day, r["Time Slot"], r["Course Code"], r.Teacher, r["Semester & Section"], r.Room]
        .join(" ")
        .toLowerCase()
        .includes(f.q);

    const matchDay = !f.day || r.Day === f.day;
    const matchSlot = !f.slot || r["Time Slot"] === f.slot;
    const matchCourse = !f.course || r["Course Code"] === f.course;
    const matchTeacher = !f.teacher || r.Teacher === f.teacher;
    const matchSemSec = !f.semsec || r["Semester & Section"] === f.semsec;
    const matchRoom = !f.room || r.Room === f.room;

    return matchQ && matchDay && matchSlot && matchCourse && matchTeacher && matchSemSec && matchRoom;
  });
}

function render(rows) {
  const filtered = applyFilters(rows);

  // Sort: Day, Slot number, Course Code, Room
  filtered.sort((a, b) => {
    if (a.Day !== b.Day) return a.Day.localeCompare(b.Day);
    const sa = slotOrder(a["Time Slot"]);
    const sb = slotOrder(b["Time Slot"]);
    if (sa !== sb) return sa - sb;
    if (a["Time Slot"] !== b["Time Slot"]) return (a["Time Slot"] || "").localeCompare(b["Time Slot"] || "");
    if (a["Course Code"] !== b["Course Code"]) return (a["Course Code"] || "").localeCompare(b["Course Code"] || "");
    return (a.Room || "").localeCompare(b.Room || "");
  });

  els.count.textContent = `${filtered.length} class(es) found`;

  els.tbody.innerHTML = filtered.map(r => `
    <tr>
      <td><span class="badge">${escapeHtml(r.Day)}</span></td>
      <td>${escapeHtml(r["Time Slot"])}</td>
      <td><span class="badge">${escapeHtml(r["Course Code"])}</span></td>
      <td>${escapeHtml(r.Teacher)}</td>
      <td>${escapeHtml(r["Semester & Section"])}</td>
      <td>${escapeHtml(r.Room)}</td>
    </tr>
  `).join("");

  if (!filtered.length) {
    els.tbody.innerHTML = `<tr><td colspan="6" class="muted">No matches. Try changing filters or clearing Search.</td></tr>`;
  }
}

function escapeHtml(str) {
  return String(str ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

async function init() {
  const res = await fetch("./routine_clean.csv", { cache: "no-store" });
  const text = await res.text();
  const rows = parseCSV(text);

  // Build filter options
  fillSelect(els.day, uniq(rows.map(r => r.Day)).sort(), "All days");

  const slots = uniq(rows.map(r => r["Time Slot"])).sort((a,b)=>slotOrder(a)-slotOrder(b));
  fillSelect(els.slot, slots, "All slots");

  fillSelect(els.course, uniq(rows.map(r => r["Course Code"])).sort(), "All courses");
  fillSelect(els.teacher, uniq(rows.map(r => r.Teacher)).sort(), "All teachers");
  fillSelect(els.semsec, uniq(rows.map(r => r["Semester & Section"])).sort(), "All semesters/sections");
  fillSelect(els.room, uniq(rows.map(r => r.Room)).sort(), "All rooms");

  // Hook events
  const rerender = () => render(rows);
  ["input","change"].forEach(ev => {
    els.q.addEventListener(ev, rerender);
  });

  [els.day, els.slot, els.course, els.teacher, els.semsec, els.room].forEach(sel => {
    sel.addEventListener("change", rerender);
  });

  els.reset.addEventListener("click", () => {
    els.q.value = "";
    [els.day, els.slot, els.course, els.teacher, els.semsec, els.room].forEach(sel => sel.value = "");
    render(rows);
  });

  render(rows);
}

init().catch(err => {
  console.error(err);
  els.count.textContent = "Failed to load routine_clean.csv";
  els.tbody.innerHTML = `<tr><td colspan="6" class="muted">Error: ${String(err)}</td></tr>`;
});
